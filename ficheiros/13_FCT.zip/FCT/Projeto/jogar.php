﻿<?php
	session_start();
	isset($_SESSION['idUser']);
?>
<html>
	<head>
	
	
	<script>
		
	
		
		var timer = setInterval(function() {varrimento()},1000);
		var conta=1;
		function varrimento(){
			switch(conta){
				case 1: 
					document.getElementById('box1').style.borderColor="red";
					document.getElementById('box2').style.borderColor='black';
					document.getElementById('box3').style.borderColor='black';
				break;
				case 2: 
					document.getElementById('box1').style.borderColor='black';
					document.getElementById('box2').style.borderColor="red";
					document.getElementById('box3').style.borderColor='black';
				break;
				case 3: 
					document.getElementById('box1').style.borderColor='black';
					document.getElementById('box2').style.borderColor='black';
					document.getElementById('box3').style.borderColor="red";
				break;
				
			}
			conta++;
			if(conta == 4) conta = 1;
		}
		
			function mostrarRegistar () {
				document.getElementById('registar').style.display='block';
				document.getElementById('login').style.display='none';
				document.getElementById('txt').style.display='none';
				document.getElementById('txt1').style.display='none';
				document.getElementById('const').style.display='none';
				document.getElementById('editAvancadas').style.display='none';
				document.getElementById('jogar').style.display='none';
				document.getElementById('footer').style.display='block';
				document.getElementById('bar').style.display='block';
				document.getElementById('criarTitulo').style.display='none';
			}
			function mostrarEditarUser () {
				document.getElementById('registar').style.display='none';
				document.getElementById('login').style.display='none';
				document.getElementById('txt').style.display='none';
				document.getElementById('txt1').style.display='none';
				document.getElementById('const').style.display='none';
				document.getElementById('editAvancadas').style.display='block';
				document.getElementById('jogar').style.display='none';
				document.getElementById('footer').style.display='block';
				document.getElementById('bar').style.display='block';
				document.getElementById('criarTitulo').style.display='none';
			}
			
			function mostrarTexto () {
				document.getElementById('txt').style.display='block';
				document.getElementById('login').style.display='none';
				document.getElementById('registar').style.display='none';
				document.getElementById('txt1').style.display='none';
				document.getElementById('const').style.display='none';
				document.getElementById('editAvancadas').style.display='none';
				document.getElementById('jogar').style.display='none';
				document.getElementById('footer').style.display='block';
				document.getElementById('bar').style.display='block';
				document.getElementById('criarTitulo').style.display='none';
			}
			
			function mostrarConst () {
				document.getElementById('txt').style.display='none';
				document.getElementById('login').style.display='none';
				document.getElementById('registar').style.display='none';
				document.getElementById('txt1').style.display='none';
				document.getElementById('const').style.display='block';
				document.getElementById('editAvancadas').style.display='none';
				document.getElementById('jogar').style.display='none';
				document.getElementById('footer').style.display='block';
				document.getElementById('bar').style.display='block';
				document.getElementById('criarTitulo').style.display='none';
			}
			function mostrarJogo () {
				document.getElementById('txt').style.display='none';
				document.getElementById('login').style.display='none';
				document.getElementById('registar').style.display='none';
				document.getElementById('txt1').style.display='none';
				document.getElementById('const').style.display='none';
				document.getElementById('editAvancadas').style.display='none';
				document.getElementById('jogar').style.display='block';
				document.getElementById('footer').style.display='none';
				document.getElementById('bar').style.display='none';
				document.getElementById('criarTitulo').style.display='none';
			}			
			function mostrarSeguirCriar () {
				document.getElementById('txt').style.display='none';
				document.getElementById('login').style.display='none';
				document.getElementById('registar').style.display='none';
				document.getElementById('txt1').style.display='none';
				document.getElementById('const').style.display='none';
				document.getElementById('editAvancadas').style.display='none';
				document.getElementById('jogar').style.display='none';
				document.getElementById('footer').style.display='none';
				document.getElementById('bar').style.display='none';
				document.getElementById('criarTitulo').style.display='block';
			}
			
			function mostrarErro(){
				alert("Já se encontra logado");		
			}
			
			function mostrarErro1(){
				alert("Não se pode registar enquanto estiver logado");		
			}
			
			function mostrarLoginFixe(){
				document.getElementById('loginFixe').style.display='block';
			}
	</script>
	
	</head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" href="foundation/css/foundation.css" />
		<script src="foundation/js/vendor/modernizr.js"></script>
		<script src="js/foundation/foundation.reveal.js"></script>
		<?php
			include_once('loginJogo.php');
			include_once('registarJogo.php');
		?>
	<body id='body'>
		<div class="off-canvas-wrap" data-offcanvas id="jogar" style="display:block"> 
			<div class="inner-wrap"> 
				<nav class="tab-bar"> 
					<section class="left-small">
						<a class="left-off-canvas-toggle menu-icon" href="#">
							<span></span>
						</a> 
					</section> 
					<section class="middle tab-bar-section"> 
						<h2 class="title">Titulo</h2>
					</section> 
					<section class="right-small"> 
						<a class="right-off-canvas-toggle menu-icon" href="#">
							<span></span>
						</a> 
					</section> 
				</nav> 
				<aside class="left-off-canvas-menu"> 
					<ul class="off-canvas-list"> 
						<li><label>Menu</label></li>
						<li><a href="index.php">Inicio</a></li> 
						<li>
							<?php									
							if($_SESSION != null)
								echo "<a href='index.php?criar'>Criar";
							else
								echo "<a>Criar"; 
							?> 
							</a>
						</li> 
						<li><a href="index.php?ajuda">Ajuda</a></li>
						<li><label>Entidade</label></li>
						<li><a href="http://www.cantic.org.pt/">CANTIC</a></li>
						<li><a href="http://www.cantic.org.pt/index.php?option=com_contact&view=category&catid=12&Itemid=81">Contactos</a></li>
					</ul> 
				</aside> 
				<aside class="right-off-canvas-menu"> 
					<ul class="off-canvas-list"> 
						<li><label>							
						<?php									
							if($_SESSION != null)
								echo "Utilizador - ".$_SESSION['Nome'];
								 
							else
								echo "Utilizador"; 
							?> 
							</a>
						</label></li>
						<li>
							<?php									
							if($_SESSION != null)
								echo "<a onclick='mostrarErro()'>Login</a>"; 
							else
								echo "<a data-reveal-id='firstModal'>Login</a>"; 
							?> 
							</a>
						</li>
						<li>
							<?php									
								if($_SESSION != null)
									echo "<a href='index.php?ed'>Editar Utilizador";
									 
								else
									echo "<a>Editar Utilizador</a>"; 
							?> 
							</a>
						</li>
						<li>
							<?php									
								if($_SESSION != null)
									echo "<a onclick='mostrarErro1()'>Registar</a>";
									 
								else
									echo "<a data-reveal-id='firstModal1'>Registar</a>"; 
							?> 
							</a>
						</li>
						<li>
							<?php
								if($_SESSION != null)
									echo "<a href='logout.php'>Sair</a>";
								else
									echo "<a onclick='mostrarLogin()'>Sair</a>";
							?>
						</li>						
					</ul> 
				</aside> 
				<section class="main-section"> 
				<!-- JOGO AQUI DENTRO AQUIIIIII PROCURA: 123-->
					<div class='row'>
						<div class='large-12 columns'>
							&nbsp;
						</div>
					</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-5 columns'>
								&nbsp;
							</div>
							<div class='large-2 columns'>
								<div class="imgBox">
									<br>
									<br>
									<br>
									<br>
									<br>
								</div>
							</div>
							<div class="large-5 columns">
								&nbsp;
							</div>
						</div>						
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>						
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>						
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class="large-2 columns">
								<div class="imgBox" id='box1'>
									<br>
									<br>
									<br>
									<br>
									<br>
								</div>
							</div>
							<div class='large-3 columns'>
								&nbsp;
							</div>
							<div class="large-2 columns">
								<div class="imgBox" id='box2'>
									<br>
									<br>
									<br>
									<br>
									<br>
								</div>
							</div>
							<div class="large-3 columns">
								&nbsp;
							</div>
							<div class="large-2 columns">
								<div class="imgBox" id='box3'>
									<br>
									<br>
									<br>
									<br>
									<br>
								</div>
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row' id='demo'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
				</section> 
				<a class="exit-off-canvas"></a>
			</div> 
		</div>
		<script src="foundation/js/vendor/jquery.js"></script>
		<script src="foundation/js/foundation.min.js"></script>
		<script>
		  $(document).foundation();
		    $(document).ready( function() {
				$('body').bind('keyup', function(e) {
					if (e.which == 32){//space bar
						window.clearInterval(timer);
						if(document.getElementById('box1').style.borderColor == 'red'){
							alert('clicou na caixa 1');
						}
						if(document.getElementById('box2').style.borderColor == 'red'){
							alert('clicou na caixa 2');
						}
						if(document.getElementById('box3').style.borderColor == 'red'){
							alert('clicou na caixa 3');
						}
						
					}
					
				});
			});
		</script>
	</body>
</html>