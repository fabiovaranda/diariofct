﻿<?php
	if (isset($_POST['EditEmail'])){
		$id = $_POST['id'];
		$email = $_POST['EditEmail'];
		$nome = $_POST['EditNome'];
		$newPwd = md5($_POST['newPwd']);
		$confNewPwd = md5($_POST['ConfNewPwd']);
		(isset($_POST["varrimento"])) ? $varrimento = $_POST["varrimento"] : $varrimento=1;
		(isset($_POST["corVarrimento"])) ? $corVarrimento = $_POST["corVarrimento"] : $corVarrimento=1;
		$pwd = md5($_POST['EditPwd']);
		include_once('dataAccess.php');
		$da = new DataAccess();
		session_start();
		$_SESSION['Nome'] = $nome;
		$res = $da->getEmail($email);
		if ($res > 0)
		{
			//$res1 = $da->erroEmail($id, $email);
			//if($res1 != $_POST['EditEmail']){
			echo "<script>
					alert('Email já se encontra a ser utilizado por outro utilizador.');
					window.location.assign('index.php?ed=1');
				 </script>";
			//}
		}
		else{
			if(md5($_POST['EditPwd']) == $_SESSION["pwd"]){
				if($email!="" && $newPwd != "")
				{
				$da->editarUtilizador($id, $nome, $email, $newPwd, $varrimento, $corVarrimento);
				$_SESSION['Nome'] = $nome;
				$_SESSION['Email'] = $email;
				echo "<script>alert('Utilizador editado com sucesso');
						window.location.assign('logout.php');</script>";
				}
				else
				{
					if($newPwd == "")
					{
						$da->editarUtilizador1($id, $nome, $varrimento, $corVarrimento);
						$_SESSION['Nome'] = $nome;
						$_SESSION['Email'] = $email;
						echo "<script>alert('Utilizador editado com sucesso');
							window.location.assign('logout.php');</script>";
					}
					else if($email == "")
					{
						$da->editarUtilizador2($id, $nome, $varrimento, $corVarrimento, $newPwd);
						$_SESSION['Nome'] = $nome;
						echo "<script>alert('Utilizador editado com sucesso');
							window.location.assign('logout.php');</script>";
					}
					else
					{
						$da->editarUtilizador3($id, $nome, $varrimento, $corVarrimento, $email);
						$_SESSION['Nome'] = $nome;
						$_SESSION['Email'] = $email;
						echo "<script>alert('Utilizador editado com sucesso');
							window.location.assign('logout.php');</script>";

					}
				}
			}
			else
				echo "<script>alert('Password Inválida');
						window.location.assign('index.php?ed=1');</script>";
		}
	}
?>
<script>
	function ReValidarEmail1(){
		if(document.getElementById('EditEmail').value != "")
		{
			//alert("ola");
			var er = /^[a-zA-Z0-9\._-]+@[a-z]+\.[a-z]{2,3}(\.[a-z]{2,3})?$/;
			if(!er.test(document.getElementById("EditEmail").value))
			{
				document.getElementById('editErro').style.display='block';
				return false;
			}
		}
		else{
			if(document.getElementById('newPwd').value != "")
			{
				var er1 = /^[a-zA-Z]\w{3,14}$/;
					if( !er1.test(document.getElementById("newPwd").value))
				{
					alert('Palavra passe deve conter entre 3 e 14 carateres de A a Z');
					return false;
				}
				else
				{
					if (document.getElementById("newPwd").value != document.getElementById("ConfNewPwd").value)
					{
						document.getElementById('erro1').style.display='block';
						return false;
					}
					else
					{
						return true;
					}
				}
			}			
		}
	}
</script>

<div class='row' style='position:relative; margin-bottom:15%; display:none;' id = 'editAvancadas'>
	<div class='large-2 columns'>
		&nbsp;
	</div>
	<div class='row'>
		<div class='large-8 panel columns'>
			<form method='post' action='editAvancadas.php' onsubmit = 'return ReValidarEmail1()'>
				<div class='row'>
					<div class = 'large-4 columns'>
					<input type='hidden' name='id' value = <?php echo $_SESSION['idUser']; ?>/>
						<img src="utilizador.png" width="100px" height = "100px"/>
					</div>
					<div class="large-4 columns"><font size='2'>Varrimento</font>
						<select id = 'varrimento' name = 'varrimento' style="color:white;background-color: #f04124;border-radius:15px;">
							<option value="6000">6 secs</option>
							<option value="5000">5 secs</option>
							<option value="4000" selected>4 secs</option>
							<option value="3000">3 secs</option>
							<option value="2000">2 secs</option>
						</select>
					</div>
					<div class="large-4 columns"><font size='2'>Cor do Varrimento</font>
						<select id = 'corVarrimento' name = 'corVarrimento' style="color:white;background-color: #f04124;border-radius:15px;">
							<option value="vermelho">Vermelho</option>
							<option value="azul">Azul</option>
							<option value="amarelo">Amarelo</option>
						</select>
					</div>
				</div>
				<div class='row'>
					<div class='large-6 columns'>
						<br>
						<input type='hidden' name='id' value = <?php echo $_SESSION['idUser']; ?>/>
						Nome: <input type='Text' value= <?php echo $_SESSION['Nome']; ?> name='EditNome' id = 'EditNome'/>
					</div>
					<div class='large-6 columns'>
						<br>
						<input type='hidden' name='id' value = <?php echo $_SESSION['idUser']; ?>/>
						Email: <input type='text' placeholder = 'exemplo@gmail.com' name='EditEmail' id = 'EditEmail' onchange = 'ReValidarEmail1()'/>
						<font style = 'color:red; display:none;' size = '1.5' id = 'editErro'>*E-Mail inválido</font>
					</div>
				</div>
				<div class='row'>
					<div class='large-12 columns'>
						Password Atual: <input type='password' placeholder='Password' name='EditPwd' id = 'EditPwd' required/>
					</div>
				</div>
				<div class='row'>
					<div class='large-12 columns'>
						Nova Password: <input type='password' placeholder='Password' name='newPwd' id = 'newPwd'/>
					</div>
				</div>
				<div class='row'>
					<div class='large-12 columns'>
						Confirmar Nova Password: <input type='password' placeholder='Password' name='ConfNewPwd' id = 'ConfNewPwd'/>
						<font style = 'color:red; display:none;' size = '1.5' id = 'erro1'>*Password não corresponde</font>
					</div>
				</div>
				<div class='row'>
					<div class='large-12 large-centered columns' align="center">
						<input type='submit' class='medium alert button' value='Confirmar' />
						<a class='medium alert button' href='index.php'>Cancelar</a>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>