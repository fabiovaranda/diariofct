<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" href="foundation/css/foundation.css" />
		<script src="foundation/js/vendor/modernizr.js"></script>
	</head>
	<body>
		<div class="reveal-modal-bg" tabindex="1000" style="display: none; -webkit-transform-origin: 0px 0px 0px; opacity: 1; -webkit-transform: scale(1, 1); visibility: visible; top: 100px;" id="loginFixe"></div>
		<div id="firstModal1" class="reveal-modal tiny open" data-reveal>
			<div class='row'>
				<div class='large-3 columns'>
						&nbsp;
					</div>
				<div class='row'>
					<div class="large-12 columns" align="center">
							<h2><font color = '#333333'><b>Registar</b></font></h2>
					</div>
					<form method='post' action = 'registar.php' onsubmit = " return ValidarEmail()">
						<div class='row'>
							<div class='large-12 columns'>
								Nome:<input type='Text' placeholder='Nome' name='Nome' id='Nome' required />
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								E-Mail: <input type='text' placeholder='exemplo@gmail.com' name='Email' id='Email' onchange = 'ValidarEmail()' required />
								<font style = 'color:red; display:none;' size = '1.5' id = 'erro'>*E-Mail inválido</font>
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								Password: <input type='password' placeholder='Password' name='pwd' id='pwd' required />
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								Confirmar Password: <input type='password' placeholder='Confirmar Password' name='Cpwd' id ='Cpwd' required />
								<font style = 'color:red; display:none;' size = '1.5' id = 'erro1'>*Password não corresponde</font>
							</div>
						</div>
						<div class='row'>
							<div class='large-12 large-centered columns' align="center">
								<input type='submit' class='medium alert button' value='Registar'/>
								<a class='medium alert button'  data-reveal-id='firstModal'>Login</a>
							</div>
						</div>
					</form>
				</div>
			</div>
			<a class="close-reveal-modal">&#215;</a>
		</div>
		<script src="foundation/js/vendor/jquery.js"></script>
		<script src="foundation/js/foundation.min.js"></script>
		<script src="js/foundation/foundation.reveal.js"></script>
		<script>
		  $(document).foundation();
		</script>
	</body>
</html>