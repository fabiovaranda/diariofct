<html>
	<head>
		<title>PLS</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" href="foundation/css/foundation.css" />
		<script src="foundation/js/vendor/modernizr.js"></script>
	</head>
	<body>
		<div class='row' id = 'acertou' style="display:none">
			<div class='large-6 panel columns'>
				<div class="row">
					<div class='large-2 columns'>
						&nbsp;
					</div>
					<div class='large-8 columns' align="center">
						<h4>Boa, acertaste!<h4>
						<img src="acertou1.png"/>
					</div>
					<div class='large-2 columns'>
						&nbsp;
					</div>
				</div>
				<div class="row">
					<div class='large-12 columns'>
						<div class='large-4 columns'>
							<a href="index.php"><img src="home.png" width="55px" height="55px"/></a>
						</div>
						<div class='large-4 columns' align="center">
							&nbsp;
						</div>
						<div class='large-4 columns' align="right">
							<img src="next.png" width="55px" height="55px"/>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script src="foundation/js/vendor/jquery.js"></script>
		<script src="foundation/js/foundation.min.js"></script>
		<script>
		  $(document).foundation();
		</script>
	</body>
</html>