<script>
	function mostrarBtJogar () {
		document.getElementById('btLogin').style.display='none';
		document.getElementById('btRegistar').style.display='none';
		document.getElementById('btJogo').style.display='block';

	}
	
	function esconderBtJogar () {
	document.getElementById('btLogin').style.display='block';
	document.getElementById('btRegistar').style.display='block';
	document.getElementById('btJogo').style.display='none';

	}
</script>
<div class = 'box' style = 'position:relative; top:7%;' id ='txt1'>
	<div class = 'large-2 columns'>
		&nbsp;
	</div>
	<div class = 'large-8 columns'>
		<font face = 'Arial'>
			<h5>Propósito</h5>
			Este web site foi construido pela a empresa <b>CANTIC</b> com o propósito de ajudar as pessoas com problemas.<br>
			<br>
			<h5>Introdução</h5>
			Este web site tem como objetivo criar e jogar um jogo de imagens correspondentes. Para criar precisa estar registado no web site e pode 
			efectuar o mesmo clicando em "Login/Registo". Para jogar basta ir ao menu e clicar em "Jogar" para mais dúvidas contacte-nos ou clique em Ajuda.
			<br>
			<br>
			<h5>Obrigado e Divirtam-se!</h5>
		</font>
		<br>
		<br>
		<br>
		<div class = 'row'>
			<div class = 'large-4 columns' align = "left">
				<a class='medium alert button' onclick='mostrarLogin()' id = 'btLogin' style = 'display:none;'>Login</a>
			</div>
			<div class = 'large-4 columns'>
				<a class='medium alert button' href="jogar.php" id = 'btJogo' style = 'display:none;'>Jogar</a>
			</div>
			<div class = 'large-4 columns' align = "right">
				<a class='medium alert button' onclick='mostrarRegistar()' id = 'btRegistar' style = 'display:none;'>Registar</a>
			</div>
		</div>
		
<?php
	if($_SESSION != null)
		echo "<script>mostrarBtJogar();</script>" ;
	else
		echo "<script>esconderBtJogar();</script>" ;
?>
	</div>
	<div class = 'large-2 columns'>
		&nbsp;
	</div>
</div>