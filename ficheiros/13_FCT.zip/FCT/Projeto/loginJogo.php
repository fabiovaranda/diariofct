<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" href="foundation/css/foundation.css" />
		<script src="foundation/js/vendor/modernizr.js"></script>
	</head>
	<body>
		<div class="reveal-modal-bg" tabindex="1000" style="display: none; -webkit-transform-origin: 0px 0px 0px; opacity: 1; -webkit-transform: scale(1, 1); visibility: visible; top: 100px;" id="loginFixe"></div>
		<div id="firstModal" class="reveal-modal tiny open" data-reveal>
			<div class='large-3 columns'>
					&nbsp;	
				</div>
			<div class='row'>
				<div class = 'row'>
					<div class = 'large-6 columns' align = "left">
					 <h2><font color = '#333333'><b>Login</b></font></h2>
					</div>
				</div>
				<form method='post' action = 'doLogin.php'>
					<div class='row'>
						<div class='large-12 columns'>
							<input onchange='return verificarEmail()' type='text' placeholder='exemplo@gmail.com' name='Email'/>
							<div id='erroEmail' style='display:none;' class='erroEmail'><font color='red'>*Email inválido</font></div>
						</div>
					</div>
					<div class='row'>
						<div class='large-12 columns'>
							<input type='password' placeholder='Password' name='pwd'/>
						</div>
					</div>
					<div class='row'>
						<div class='large-12 large-centered columns'>
							<input type='submit' class='medium alert button left' value='Entrar' />
							<a class='medium alert button right' data-reveal-id='firstModal1'>Registar</a>
						</div>
					</div>
				</form>
			</div>
			<a class="close-reveal-modal">&#215;</a>
		</div>
		<script src="foundation/js/vendor/jquery.js"></script>
		<script src="foundation/js/foundation.min.js"></script>
		<script src="js/foundation/foundation.reveal.js"></script>
		<script>
		  $(document).foundation();
		</script>
	</body>
</html>