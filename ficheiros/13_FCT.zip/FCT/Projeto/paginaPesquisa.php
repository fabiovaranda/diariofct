<html>
	<head>
	</head>
	<body>
		Voçê pesquisou por:
		...
	</body>
</html>