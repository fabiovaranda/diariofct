<div class = 'box' style = 'position:relative; top:3%; display:none;' id ='txt'>
	<div class = 'large-2 columns'>
		&nbsp;
	</div>
	<div class = 'large-8 columns'>
		<font face = 'Arial'>
			<h5>Login/Registo</h5>
			Para aceder à aplicação pode ir ao menu e clicar em jogar caso deseje um género de jogo em específico pode pesquisar pelo mesmo. Para criar o seu 
			próprio jogo, tem de criar uma conta e pode fazer isso clicando em "Login/Registar", caso já tenha uma conta criada e deseja fazer login o processo 
			é o mesmo, ao clicar no mesmo aparecerá uma janela a dizer login, caso esteje interessado em se registar basta selecionar o botão "Registar" que 
			lhe fará aparecer o menu de registo, para se registar deve indicar o nome pelo o qual quer ser conhecido ao criar a atividade, o seu email,
			 a password e deve tambem confirmar a mesma.
			Ao ter feito login pode criar e tambem jogar.<br>
			<br>
			<h5>Criação</h5>
			Para criar necessita de 4 imagens em que duas se relacionem e tem de definir a imagem central que se relacionará com uma das opções (outras imagens)
			e definir qual a opção correta, também vai ter que definir o tempo de varramento que varia entre os 6 segundos e os 2 segundos, podendo também definir
			a cor de fundo de acordo com o que achar melhor.<br>
			<br>
			<h5>Explicação do Jogo</h5>
			Temos 3 imagens e uma principal temos de arranjar uma correspondência entre a principal e uma das outras 3 imagens ao arranjarmos clicamos na imagem que achamos correta
			ao clicar aparecerá uma janela a dizer se está certo ou errado caso esteje errado pode tentar outra vez ou voltar à página principal, caso esteje certa pode avançar ou ir para a página inicial.
		</font>
	</div>
	<div class = 'large-2 columns'>
		&nbsp;
	</div>
</div>