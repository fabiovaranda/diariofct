<div class = 'row' style = 'position:fixed; bottom:0; left:48%; margin-left:-475px' id="footer">
	<div class = 'large-12 columns'>
		<nav class="top-bar" data-topbar role="navigation"> 
			<section class="top-bar-section">
				<ul class="right" style = 'position:relative; padding-top:1%;'> 
					<a href = "http://www.cantic.org.pt/"><font color = 'white' size = '1'>CANTIC</font> </a>
					<font color = 'white' size = '1'>| </font>
					<a href = "http://www.cantic.org.pt/index.php?option=com_contact&view=category&catid=12&Itemid=81"><font color = 'white' size = '1'>Contactos</font></a>
					<font color = 'white' size = '1'>|</font>
					<a onclick='mostrarTexto ()'><font color = 'white' size = '1'>Help</font></a>
					<font size = '1' color = 'white'>| Pedro Lima | Luis Varela</font>&nbsp; &nbsp;
				</ul>
			</section> 
		</nav>
	</div>
</div>