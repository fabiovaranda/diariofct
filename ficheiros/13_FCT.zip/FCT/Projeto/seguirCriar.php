<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" href="foundation/css/foundation.css" />
		<script src="foundation/js/vendor/modernizr.js"></script>
	</head>
	<?php
		include_once('topbar.php');
		include_once('testFooter.php');	
	?>
	<body>
		<div class='row' style='position:relative; top:23%; display:none; fixed; ' id = "criarTitulo">
			<div class='large-3 columns'>
					&nbsp;	
				</div>
			<div class='row'>
				<div class='large-5 panel columns'>
					<form method='post'>
						<div class='row'>
							<div class='large-12 columns'>
								<h2>Título:<input type='text' name='titulo'/></h2>
							</div>
						</div>
						<div class='row'>
							<div class='large-8 large-centered columns'>
								<input type='submit' class='medium alert button' value='Criar' />
								<a class='medium alert button' href="index.php">Cancelar</a>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<script src="foundation/js/vendor/jquery.js"></script>
		<script src="foundation/js/foundation.min.js"></script>
		<script>
		  $(document).foundation();
		</script>
	</body>
</html>