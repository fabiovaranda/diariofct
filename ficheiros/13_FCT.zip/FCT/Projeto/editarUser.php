<?php
	if (isset($_POST['EditEmail'])){
	$id = $_POST['id'];
	$email = $_POST['EditEmail'];
	$nome = $_POST['EditNome'];
	$pwd = md5($_POST['EditPwd']);
	include_once('dataAccess.php');
	$da = new DataAccess();
	$da->editarUtilizador($id, $nome, $email, $pwd);
	session_start();
	$_SESSION['Nome'] = $nome;
	echo "<script>alert('Utilizador editado com sucesso');
	window.location.assign('index.php');</script>";
	}
?>
<script>
	function ReValidarEmail(){
		var er = /^[a-zA-Z0-9\._-]+@[a-z]+\.[a-z]{2,3}(\.[a-z]{2,3})?$/;
		if( !er.test(document.getElementById("EditEmail").value))
		{
			document.getElementById('editErro').style.display='block';
			return false;
		}
		else{
			/*if (<?php $_SESSION['pwd'] ?> != document.getElementById("EditPwd").value)
			{
				alert("Password inválida");
				return false;
			}
			else
			{
				return true;
			}*/
			return true;
		}
	}
</script>
<div class='row' style='position:relative; top:9%; display:none; cursor:;' id = 'editar'>
	<div class='large-3 columns'>
		&nbsp;
	</div>
	<div class='row'>
		<div class='large-5 panel columns'>
			<form method='post' action='editarUser.php' onsubmit = 'return ReValidarEmail()'>
				<div class='row'>
					<div class = 'large-4 columns'>
						<img src="utilizador.png" width="100px" height = "100px"/>
					</div>
					<div class='large-8 columns'>
					<input type='hidden' name='id' value = <?php echo $_SESSION['idUser']; ?>/>
						Nome: <input type='Text' value= <?php echo $_SESSION['Nome']; ?> name='EditNome' id = 'EditNome'/>
					</div>
				</div>
				<div class='row'>
					<div class='large-12 columns'>
					<br>
						Email: <input type='text' value=<?php echo $_SESSION['Email']; ?> name='EditEmail' id = 'EditEmail' onchange = 'ReValidarEmail()' required/>
						<font style = 'color:red; display:none;' size = '1.5' id = 'editErro'>*E-Mail inválido</font>
					</div>
				</div>
				<div class='row'>
					<div class='large-12 columns'>
						Password: <input type='password' placeholder='Password' name='EditPwd' id = 'EditPwd' required/>
					</div>
				</div>
				<div class='row'>
					<div class='large-9 large-centered columns'>
						<input type='submit' class='medium alert button' value='Confirmar' />
						<a class='medium alert button' href='index.php'>Cancelar</a>
					</div>
				</div>
				<div class='row'>
					<div class = 'large-4 columns' align = 'right'>
						&nbsp;
					</div>
					<div class = 'large-4 columns' align = 'right'>
						&nbsp;
					</div>
					<div class = 'large-4 columns' align = 'right'>
						<a onclick = 'mostrarDefinicoesAvancadas()'><font size = '1' color = 'blue'>Definições avançadas</font></a>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>