<div class='row' style='position:relative; top:23%; left:4%; display:none; fixed; ' id = "login">
	<div class='large-3 columns'>
			&nbsp;	
		</div>
	<div class='row'>
		<div class='large-5 panel columns'>
			<div class = 'row'>
				<div class = 'large-4 columns'>
					&nbsp;
				</div>
				<div class = 'large-4 columns'>
				 <h2><font color = '#333333'><b>Login</b></font></h2>
				</div>
				<div class = 'large-4 columns' align = "right">
					<a href = "index.php"><font color="black">X</font></a>
				</div>
			</div>
			<form method='post' action = 'doLogin.php'>
			<div class='row'>
				<div class='large-12 columns'>
					<input onchange='return verificarEmail()' type='text' placeholder='exemplo@gmail.com' name='Email'/>
					<div id='erroEmail' style='display:none;' class='erroEmail'><font color='red'>*Email inválido</font></div>
				</div>
			</div>
			<div class='row'>
				<div class='large-12 columns'>
					<input type='password' placeholder='Password' name='pwd'/>
				</div>
			</div>
			<div class='row'>
				<div class='large-8 large-centered columns'>
					<input type='submit' class='medium alert button' value='Entrar' />
					<a class='medium alert button' onclick='mostrarRegistar()'>Registar</a>
				</div>
			</div>
			</form>
		</div>
	</div>
</div>