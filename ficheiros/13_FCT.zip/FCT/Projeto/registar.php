﻿<?php
	if (isset($_POST['Nome'])){
		//registar novo user
		$nome = $_POST['Nome'];
		$email = $_POST['Email'];
		$pwd = md5($_POST['pwd']);
		include_once('dataAccess.php');
		$da = new DataAccess();
		$res = $da->getEmail($email);
		
		if ($res > 0)
		{
			echo "<script>alert ('Email já em uso');
					window.location='index.php?registoError';</script>";

		}
		else
		{
			$da->inserirUtilizador($nome, $email, $pwd);
			echo "<script>alert('Utilizador registado com sucesso');
						window.location='index.php';</script>";
		}	
	}	
?>
<html>
	<head>
		<script>
			function ValidarEmail(){
				var er = /^[a-zA-Z0-9\._-]+@[a-z]+\.[a-z]{2,3}(\.[a-z]{2,3})?$/;
				if( !er.test(document.getElementById("Email").value))
				{
					document.getElementById('erro').style.display='block';
					return false;
				}
				else{
					var er1 = /^[a-zA-Z]\w{3,14}$/;
						if( !er1.test(document.getElementById("pwd").value))
					{
						alert('Palavra passe deve conter entre 3 e 14 carateres de A a Z');
						return false;
					}
					else
					{
						if (document.getElementById("pwd").value != document.getElementById("Cpwd").value)
						{
							document.getElementById('erro1').style.display='block';
							return false;
						}
						else
						{
							return true;
						}
					}
				}
			}
		</script>
</head>
<?php

?>
<body>
	<div class='row' style='position:relative; top:8%; display:none; left:55%; margin-left:-515px;' id = "registar">
		<div class='large-3 columns'>
				&nbsp;
			</div>
		<div class='row'>
			<div class='large-5 panel columns'>
				<div class = 'row'>
					<div class = 'large-3 columns'>
						&nbsp;
					</div>
					<div class = 'large-4 columns'>
					 <h2><font color = '#333333'><b>Registar</b></font></h2>
					</div>
					<div class='large-5 columns' align = "right">
						<a href = "index.php"><font color="black">X</font></a>
					</div>
				</div>
				<form method='post' action = 'registar.php' onsubmit = " return ValidarEmail()">
					<div class='row'>
						<div class='large-12 columns'>
							Nome:<input type='Text' placeholder='Nome' name='Nome' id='Nome' required />
						</div>
					</div>
					<div class='row'>
						<div class='large-12 columns'>
							E-Mail: <input type='text' placeholder='exemplo@gmail.com' name='Email' id='Email' onchange = 'ValidarEmail()' required />
							<font style = 'color:red; display:none;' size = '1.5' id = 'erro'>*E-Mail inválido</font>
						</div>
					</div>
					<div class='row'>
						<div class='large-12 columns'>
							Password: <input type='password' placeholder='Password' name='pwd' id='pwd' required />
						</div>
					</div>
					<div class='row'>
						<div class='large-12 columns'>
							Confirmar Password: <input type='password' placeholder='Confirmar Password' name='Cpwd' id ='Cpwd' required />
							<font style = 'color:red; display:none;' size = '1.5' id = 'erro1'>*Password não corresponde</font>
						</div>
					</div>
					<div class='row'>
						<div class='large-8 large-centered columns'>
							<input type='submit' class='medium alert button' value='Registar'/>
							<a class='medium alert button' onclick='mostrarLogin()'>Login</a>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>