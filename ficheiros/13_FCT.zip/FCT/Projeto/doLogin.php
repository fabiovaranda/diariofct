<?php
	if (isset($_POST['Email'])){
		//tentar efetuar login
		$email = $_POST['Email'];
		$pwd = md5($_POST['pwd']); //md5 serve para encriptar a password
		include_once('dataAccess.php');
		$da = new DataAccess();
		$res = $da->login($email, $pwd);
		//echo $pwd;
		//Se a variável $res tiver resultados, significa que o login foi efetuado com sucesso
		if (mysqli_num_rows($res) > 0) {
			$row = mysqli_fetch_object($res);
			session_start();			
			$_SESSION['idUser'] = $row->id;
			$_SESSION['Nome'] = $row->nome;
			$_SESSION['Email'] = $row->email;
			$_SESSION['pwd'] = $row->pwd;
			echo "<script>alert('Login efetuado com sucesso'); window.location='index.php'</script>";
		}else{	
			echo "<script>alert('Login incorreto'); window.location='index.php?loginError'</script>";
		}
	}
?>