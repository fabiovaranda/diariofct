<?php
	session_start();
	isset($_SESSION['idUser']);
?>
<html>
	<head>
		<title>PLS</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" href="foundation/css/foundation.css" />
		<script src="foundation/js/vendor/modernizr.js"></script>
	</head>
	<body>
		<script>
			function mostrarLogin () {
				document.getElementById('login').style.display='block';
				document.getElementById('registar').style.display='none';
				document.getElementById('txt').style.display='none';
				document.getElementById('txt1').style.display='none';
				document.getElementById('const').style.display='none';
				document.getElementById('editAvancadas').style.display='none';
				document.getElementById('jogar').style.display='none';
				document.getElementById('footer').style.display='block';
				document.getElementById('bar').style.display='block';
				document.getElementById('criarTitulo').style.display='none';
			}
			
			function mostrarRegistar () {
				document.getElementById('registar').style.display='block';
				document.getElementById('login').style.display='none';
				document.getElementById('txt').style.display='none';
				document.getElementById('txt1').style.display='none';
				document.getElementById('const').style.display='none';
				document.getElementById('editAvancadas').style.display='none';
				document.getElementById('jogar').style.display='none';
				document.getElementById('footer').style.display='block';
				document.getElementById('bar').style.display='block';
				document.getElementById('criarTitulo').style.display='none';
			}
			function mostrarEditarUser () {
				document.getElementById('registar').style.display='none';
				document.getElementById('login').style.display='none';
				document.getElementById('txt').style.display='none';
				document.getElementById('txt1').style.display='none';
				document.getElementById('const').style.display='none';
				document.getElementById('editAvancadas').style.display='block';
				document.getElementById('jogar').style.display='none';
				document.getElementById('footer').style.display='block';
				document.getElementById('bar').style.display='block';
				document.getElementById('criarTitulo').style.display='none';
			}
			
			function mostrarTexto () {
				document.getElementById('txt').style.display='block';
				document.getElementById('login').style.display='none';
				document.getElementById('registar').style.display='none';
				document.getElementById('txt1').style.display='none';
				document.getElementById('const').style.display='none';
				document.getElementById('editAvancadas').style.display='none';
				document.getElementById('jogar').style.display='none';
				document.getElementById('footer').style.display='block';
				document.getElementById('bar').style.display='block';
				document.getElementById('criarTitulo').style.display='none';
			}
			
			function mostrarConst () {
				document.getElementById('txt').style.display='none';
				document.getElementById('login').style.display='none';
				document.getElementById('registar').style.display='none';
				document.getElementById('txt1').style.display='none';
				document.getElementById('const').style.display='block';
				document.getElementById('editAvancadas').style.display='none';
				document.getElementById('jogar').style.display='none';
				document.getElementById('footer').style.display='block';
				document.getElementById('bar').style.display='block';
				document.getElementById('criarTitulo').style.display='none';
			}
			function mostrarJogo () {
				document.getElementById('txt').style.display='none';
				document.getElementById('login').style.display='none';
				document.getElementById('registar').style.display='none';
				document.getElementById('txt1').style.display='none';
				document.getElementById('const').style.display='none';
				document.getElementById('editAvancadas').style.display='none';
				document.getElementById('jogar').style.display='block';
				document.getElementById('footer').style.display='none';
				document.getElementById('bar').style.display='none';
				document.getElementById('criarTitulo').style.display='none';
			}			
			function mostrarSeguirCriar () {
				document.getElementById('txt').style.display='none';
				document.getElementById('login').style.display='none';
				document.getElementById('registar').style.display='none';
				document.getElementById('txt1').style.display='none';
				document.getElementById('const').style.display='none';
				document.getElementById('editAvancadas').style.display='none';
				document.getElementById('jogar').style.display='none';
				document.getElementById('footer').style.display='none';
				document.getElementById('bar').style.display='none';
				document.getElementById('criarTitulo').style.display='block';
			}
		
			
		</script>
		<?php
			include_once('topbar.php');
			include_once('textoExplicativo.php');
			include_once('textoBreve.php');
			include_once('login.php');
			include_once('seguirCriar.php');
			include_once('editAvancadas.php');
			include_once('registar.php');
			include_once('editarUser.php');
			include_once('testFooter.php');
			include_once('construtor.php');
			if($_SERVER['QUERY_STRING'] == 'loginError') echo "<script>mostrarLogin();</script>";
			else if($_SERVER['QUERY_STRING'] == 'registoError')
				echo "<script>mostrarRegistar();</script>";
		?>
		<script src="foundation/js/vendor/jquery.js"></script>
		<script src="foundation/js/foundation.min.js"></script>
		<script>
		  $(document).foundation();
		</script>
		<?php
			if (isset($_GET['ed'])) echo "<script>mostrarEditarUser();</script>";
			if (isset($_GET['login'])) echo "<script>mostrarLogin();</script>";
			if (isset($_GET['register'])) echo "<script>mostrarRegistar()</script>";
			if (isset($_GET['criar'])) echo "<script>mostrarConst()</script>";
			if (isset($_GET['ajuda'])) echo "<script>mostrarTexto()</script>";
		?>
	</body>
</html>