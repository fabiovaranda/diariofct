<?php

class DataAccess{
    private $connection;
	
    function connect(){
        $bd= "teste";
        $user = "root";
        $pwd = "";
        $server = "localhost";
		$this->connection = mysqli_connect($server,$user,$pwd,$bd);

		// Check connection
		if (mysqli_connect_errno())
		{
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}else{
            mysqli_query($this->connection, "set names 'utf8'");
            mysqli_query($this->connection, "set character_set_connection=utf8");
            mysqli_query($this->connection, "set character_set_client=utf8");
            mysqli_query($this->connection, "set character_set_results=utf8");
        }
    }
    
    function execute($query){
        $res = mysqli_query($this->connection, $query);
        if(!$res){
            die("Comando inválido".mysqli_error($this->connection));
        }else
            return $res;
    }
    
    function disconnect(){
        mysqli_close($this->connection);
    }

	public function inserirUtilizador($nome, $email, $pwd){
		$query = "insert into utilizadores(nome, email, pwd) values
										('$nome', '$email', '$pwd')";
		$this->connect();
		$this->execute($query);
		$id = $this->connection->insert_id;
		$this->disconnect();
		return $id;
	}
	
	function login($email, $password){
		$query = "select * from utilizadores where email ='$email' and pwd = '$password'";
		$this->connect();
		$res = $this->execute($query);
		$this->disconnect();
		return $res;
	}
	function deleteUser($id){
		$query = "delete from utilizadores where id = $id";
		$this->connect();
		$this->execute($query);
		$this->disconnect();
	}
	
	function editarUtilizador($id, $nome, $email, $newPwd, $varrimento, $corVarrimento){
		$query = "update utilizadores set nome='$nome', email='$email', pwd = '$newPwd', varrimento = '$varrimento', corVarrimento = '$corVarrimento' where id='$id'";
		$this->connect();
		$this->execute($query);
		$this->disconnect();
	}
	
	function editarUtilizador1($id, $nome, $varrimento, $corVarrimento){
		$query = "update utilizadores set nome='$nome', varrimento = '$varrimento', corVarrimento = '$corVarrimento' where id='$id'";
		$this->connect();
		$this->execute($query);
		$this->disconnect();
	}
	
	function editarUtilizador2($id, $nome, $varrimento, $corVarrimento, $newPwd){
		$query = "update utilizadores set nome='$nome', varrimento = '$varrimento', corVarrimento = '$corVarrimento', pwd = '$newPwd' where id='$id'";
		$this->connect();
		$this->execute($query);
		$this->disconnect();
	}
	
	function editarUtilizador3($id, $nome, $varrimento, $corVarrimento, $email){
		$query = "update utilizadores set nome='$nome', varrimento = '$varrimento', corVarrimento = '$corVarrimento', email = '$email' where id='$id'";
		$this->connect();
		$this->execute($query);
		$this->disconnect();
	}
	function getEmail($email){
		$query = "select count(email) as contagem from utilizadores where email='$email'";
		$this->connect();
        $res = $this->execute($query);
		$row = mysqli_fetch_object($res);
		$count = $row->contagem;
		$this->disconnect();
		
		return $count;	
	}
	
	function erroEmail($id, $email){
		$query = "select email from utilizadores where id=$id";
		$this->connect();
        $res = $this->execute($query);
		$this->disconnect();
		return $res;
	}

	function inserirFicheiro($urlPrincipal){
		$query = "insert into imagens (ficheiro) values ('$urlPrincipal')";
		echo $query;
		$this->connect();
		$this->execute($query);
		$this->disconnect();
	}
	
	function ficheiros($autor, $palavraChave, $corFundo, $opcaoCorreta){
		$query = "insert into atividades (autor, palavraChave, corFundo, opcaoCorreta) values
											('$autor', '$palavraChave', '$corFundo', '$opcaoCorreta')";
		$this->connect();
		$this->execute($query);
		$this->disconnect();
	}
	
	function pesquisar($autor, $palavraChave, $titulo){
		$query = "select * from atividades where autor='$autor' or palavraChave='$palavraChave' or titulo = $titulo";
		$this->connect();
        $res = $this->execute($query);
		$this->disconnect();
		return $res;
	}
}
?>
