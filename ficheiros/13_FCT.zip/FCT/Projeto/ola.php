<html>
	<head>
	</head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" href="foundation/css/foundation.css" />
		<script src="foundation/js/vendor/modernizr.js"></script>
	<body>
		<div class="off-canvas-wrap" data-offcanvas id="ola" style="display:none"> 
			<div class="inner-wrap"> 
				<nav class="tab-bar"> 
					<section class="left-small"> 
						<a class="left-off-canvas-toggle menu-icon" href="#">
							<span></span>
						</a> 
					</section> 
					<section class="middle tab-bar-section"> 
						<h1 class="title">PLS</h1>
					</section> 
					<section class="right-small"> 
						<a class="right-off-canvas-toggle menu-icon" href="#">
							<span></span>
						</a> 
					</section> 
				</nav> 
				<aside class="left-off-canvas-menu"> 
					<ul class="off-canvas-list"> 
						<li><label>Menu</label></li>
						<li><a href="index.php">Inicio</a></li> 
						<li><a onclick="mostrarConst()">Criar</a></li> 
						<li><a onclick="mostrarTexto()">Ajuda</a></li>
					</ul> 
				</aside> 
				<aside class="right-off-canvas-menu"> 
					<ul class="off-canvas-list"> 
						<li><label>Utilizador</label></li>
						<li><a onclick="mostrarLogin()">Login</a></li>
						<li><a onclick="mostrarEditarUser()">Editar Utilizador</a></li>
						<li><a onclick="mostrarRegistar()">Registar</a></li>
						<li><a onclick="logout.php">Sair</a></li>						
					</ul> 
				</aside> 
				<section class="main-section"> 
				<!-- JOGO AQUI DENTRO AQUIIIIII PROCURA: 123-->
					<div class='row'>
						<div class='large-12 columns'>
							&nbsp;
						</div>
					</div>					
					<div class='row'>
						<div class='large-5 columns'>
							&nbsp;	
						</div>
						<div class='large-3 columns'>
							<h1><font color="darkorange"> Titulo </font><!--dado pelo utilizador--></h1>
						</div>
						<div class='large-4 columns'>
							&nbsp;
						</div>
					</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-5 columns'>
								&nbsp;
							</div>
							<div class='large-2 columns'>
								<div class="imgBox">
									<br>
									<br>
									<br>
									<br>
									<br>
								</div>
							</div>
							<div class="large-5 columns">
								&nbsp;
							</div>
						</div>						
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>						
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>						
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class='large-12 columns'>
								&nbsp;
							</div>
						</div>
						<div class='row'>
							<div class="large-2 columns">
								<div class="imgBox">
									<br>
									<br>
									<br>
									<br>
									<br>
								</div>
							</div>
							<div class='large-3 columns'>
								&nbsp;
							</div>
							<div class="large-2 columns">
								<div class="imgBox">
									<br>
									<br>
									<br>
									<br>
									<br>
								</div>
							</div>
							<div class="large-3 columns">
								&nbsp;
							</div>
							<div class="large-2 columns">
								<div class="imgBox">
									<br>
									<br>
									<br>
									<br>
									<br>
								</div>
							</div>
						</div>
				</section> 
				<a class="exit-off-canvas"></a> 
			</div> 
		</div>
		<script src="foundation/js/vendor/jquery.js"></script>
		<script src="foundation/js/foundation.min.js"></script>
		<script>
		  $(document).foundation();
		</script>
	</body>
</html>