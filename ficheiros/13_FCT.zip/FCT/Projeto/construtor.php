<?php
	
	if (isset($_POST['autor'])){
		//botão de enviar ficheiro foi clicado
		/*include_once('uploadFile.php');
		$uf = new uploadFile();
		$res = $uf->upload($_FILES['file1']);
		echo "$res";
		if ($res == -1){
			echo "<script>alert('erro ao carregar as imagens')</script>";
		}
		//else{*/
			$autor = $_POST['autor'];
			$palavraChave = $_POST['palavraChave'];
			$corFundo = $_POST['corFundo'];
			$opcaoCorreta = $_POST['opcaoCorreta'];
			include_once('DataAccess.php');
			$da = new DataAccess();
			//$da->inserirFicheiro(basename($res));
			$res = $da->ficheiros($autor, $palavraChave, $corFundo, $opcaoCorreta);
			echo "<script>alert('O jogo foi criado com sucesso')</script>";
		//}
	}
?>
<html>
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="stylesheet" href="foundation/css/foundation.css" />
	<script src="foundation/js/vendor/modernizr.js"></script>
	<!--<style>
	.file_input_button
{
	width: 100px; 
	position: absolute; 
	top: 0px;
	background-color: #33BB00;
	color: #FFFFFF;
	border-style: solid;
}

.file_input_hidden
{
	font-size: 45px; 
	position: absolute; 
	right: 0px; 
	top: 0px; 
	opacity: 0; 
	
	filter: alpha(opacity=0); 
	-ms-filter: "alpha(opacity=0)"; 
	-khtml-opacity: 0; 
	-moz-opacity: 0;
}
	</style>-->
</head>
<body>
<div class='row' style='position:relative; top:0.5%; display:none; left:44%; margin-left:-485px;' id = 'const'>
	<div class='large-3 columns'>
		&nbsp;
	</div>
	<div class='row'>
		<div class='large-7 panel columns'>
		<div class = 'row'>
			<div class ='large-4 columns'> 
				&nbsp;
			</div>
			<div class ='large-4 columns'> 
				<h2><font color = '#333333'><b>Construtor</b></font></h2>
			</div>
			<div class ='large-4 columns' align="right">
				<a href = "index.php"><font color="black">X</font></a>			
			</div>
		</div>
		<div class='row'>
			<div class='large-4 columns'>
				&nbsp;
			</div>
		</div>
			<form method='post' action='' enctype="multipart/form-data">
				<div class='row'>
					<div class="large-2 columns"><br />
						<div class="imgBox" width ="100px" height= "100px">
							&nbsp;
						</div>
					</div>
					<div class="large-5 columns"><br />
						<div class="row collapse">
							<div class="large-12 columns">
								<!-- IMG1 HERE-->
								<!--<input type='file' accept='image/*' name='file1' required/>-->
							</div>
						</div>
					</div>
					<div class='large-5 columns'>
						Palavra chave:<input  id ="palavraChave" name="palavraChave"type="text" name="palavraChave" required/>
					</div>
				</div>
				<div class='row'>				
					<div class="large-2 columns"><br />
						<div class="imgBox" width ="100px" height= "100px">
							&nbsp;
						</div>
					</div>
					<div class="large-5 columns"><br />
						<div class="row collapse">
							<div class="large-12 columns">
								<!-- IMG2 HERE-->							
								<!--<input type='file' accept='image/*' name='file1' required/>-->
							</div>
						</div>
					</div>
					<div class="large-5 columns">Opção correta
						<select id = 'opcaoCorreta' name = 'opcaoCorreta' style="color:white;background-color: #f04124;border-radius:15px;">
							<option value="1">Opção 1</option>
							<option value="2">Opção 2</option>
							<option value="3">Opção 3</option>
						</select>
					</div>
				</div>
				<div class='row'>
					<div class="large-2 columns"><br />
						<div class="imgBox" width ="100px" height= "100px">
							&nbsp;
						</div>
					</div>
					<div class="large-5 columns"><br />
						<div class="row collapse">
							<div class="large-12 columns"> 
								<!-- IMG3 HERE-->
								<!--<input type='file' accept='image/*' name='file1' required/>-->
							</div>
						</div>
					</div>
					<div class="large-5 columns">
						Cor Fundo
						<select id="corFundo" name="corFundo" style="color:white;background-color: #f04124;border-radius:15px;">
							<option value="Black">Preto</option>
							<option value="White">Branco</option>
							<option value="Blue">Azul</option>
						</select>
					</div>
				</div>
				<div class='row'>
					<div class="large-2 columns"><br/>
						<div class="imgBox" width ="100px" height= "100px">
							&nbsp;
						</div>
					</div>
					<div class="large-5 columns"><br />
						<div class="row collapse">
							<div class="large-12 columns"> 								
								<!-- IMG4 HERE-->
								<!--<input type='file' accept='image/*' name='file1' required/>-->
							</div>
						</div>
					</div>
					<div class = 'large-5 columns'>
						Autor:<input id="autor" name="autor" type="text">
					</div>	
				</div><br />
				<div class='row'>
					<div div class='large-8 large-centered columns'>
						&nbsp;
						&nbsp;
						&nbsp;
						&nbsp;
						&nbsp;
						&nbsp;
						&nbsp;
						&nbsp;
						&nbsp;
						<input type='submit' class='medium alert button' value='Avançar' name='enviarFicheiro' />
						<a class='medium alert button' href="index.php">Cancelar</a>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
	<script src="foundation/js/vendor/jquery.js"></script>
	<script src="foundation/js/foundation.min.js"></script>
	<script>
		$(document).foundation();
	</script>
</body>
</html>
