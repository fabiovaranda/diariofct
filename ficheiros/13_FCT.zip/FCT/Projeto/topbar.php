<?php
	/*$autor = $_POST['pesquisar'];
	$palavraChave = $_POST['pesquisar'];
	include_once('dataAccess.php');
	$da = new DataAccess();
	$res = $da->pesquisar($autor, $palavraChave);*/
	
?>
<div class = 'row' id ="bar">
	<div class = 'large-12 columns'>
		<nav class="top-bar" data-topbar role="navigation"> 
			<ul class="title-area"> 
				<li class="name"> 	
					<h1>
						<a href="index.php"><img src = "logoN.png" height = "100px" width = "100px"/></a>
					</h1> 
				</li>
				<li class="toggle-topbar menu-icon">
					<a href="#">
						<span>Menu</span>
					</a>
				</li>
			</ul>
			<section class="top-bar-section">
				<ul class="right"> 
					<li class="has-dropdown"> 
						<a href="#">Menu</a> 
						<ul class="dropdown"> 
							<li>
								<a href="index.php">Home</a>
							</li> 
							<li>
								<!--<a onclick ="mostrarConst()">Criar</a>-->
								<?php									
								if($_SESSION != null)
									echo "<a onclick='mostrarConst()'>Criar";
									 
								else
									echo "<a onclick='mostrarLogin()'>Criar"; 
								?> 
								</a>
							</li>
							<li>
								<a href="jogar.php">Jogar</a>
							</li>
							<li>
								<a onclick='mostrarTexto ()'>Ajuda</a>
							</li>
							<li>
								<?php
								if($_SESSION != null)
									
									echo "<a href='logout.php'>Sair</a>";
								 
								else
									echo "<a onclick='mostrarLogin()'>Sair</a>";
								?>
							</li>
						</ul> 
					</li> 
				</ul>
				<ul class="left">
					<li>
						<?php									
						if($_SESSION != null)
							echo "<a onclick='mostrarEditarUser()'><img src='utilizador.png' width='45px' height = '45px'/> &nbsp;".$_SESSION['Nome'];
							 
						else
							echo "<a onclick='mostrarLogin()'><img src='utilizador.png' width='45px' height = '45px'/> &nbsp; Login/Registo"; 
						?> 
						</a>
					</li>
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
					&nbsp;
				</ul>						
				<ul>
					<li class="has-form"> 
						<div class="row collapse">
							<div class="large-7 columns"> 
								<input id = 'pesquisar' name='pesquisar' type="text" placeholder="Pesquisar..."> 
							</div>
							<div class="large-5 columns">
								<a class="alert button expand">Pesquisar</a> 
							</div> 
						</div> 
					</li>
				</ul>
			</section> 
		</nav>
	</div>
</div>